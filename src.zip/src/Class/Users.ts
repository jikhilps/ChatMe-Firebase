export class User
{
    Id:any;
    Name:string;
    Mobile:string;
}